%
% hh_integrate.m
%
% Integrate the Hodgkin Huxley equations
%     Function takes parameters from the interface and uses an ODE
%     integrator to solve the nested equations. 
%
% PD Roberts, BME-OHSU 01/07 (modified from: Steve Cox, 1/17/03)
%
function [t,x] = hh_integrate_Zach(t, hh_param, stim_param)

%X0 = [-63 0.318 0.053 0.595 0.2212 0.01 23 0.0091]';  % initial values of [v n m h M H caconc c]
X0 = [-63 0.35 0.0676 0.521 0.2786 0.0107 23.6 0.0535]';  % initial values of [v n m h M H caconc c]
[t,x] = ode23(@hhp,[0 t],X0);  % Runge-Kutta algorithm

%=== begin nested functions ====

% Set up the Hodgkin-Huxley equations 
% Dynamic variables are stored in X = [v n m h r s caconc]'

%--- Hodgkin-Huxley equations voltage equation, pp 173 of [Dayan01] ---
function dXdt = hhp(t,X)

    dXdt = zeros(8,1);

    GNa = hh_param(1);  
    GK = hh_param(2);    
    Gl = hh_param(3);
    GKca = hh_param(4);
    GT = hh_param(5);
    vNa = hh_param(6); 
    vK = hh_param(7);
    vl = hh_param(8);
    vT = hh_param(9);
    Kpump = hh_param(10);
    F = hh_param(11);
    Cm = 1;              % capacitance density (uF / cm^2)
    A = 1.26e-5;	 % membrane area (A=4*PI*R^2, R=10u, cm^2)
    VLM = 4.19e-9/1000;    % cell volume (VLM=(4*PI*R^3)/3, R=10u, cm^3)
 
    %  stimulus is current injection
    I = 0;
    if (t>=stim_param(1) & t<=stim_param(1)+stim_param(2))
       I = stim_param(3)/1000;  % parameter in nA
    end

    % right hand sides of HH equations (26),(7),(15),(16) of [Hodgkin52]

    dXdt(1) = (1/Cm)*(-GK*(X(2)^4)*(X(1)-vK) + ...
           -GNa*(X(3)^3)*X(4)*(X(1)-vNa) - Gl*(X(1)-vl) + ...
           -GKca*X(8)^4*(X(1)-vK) - GT*(X(5)^2)*X(6)*(X(1)-vT) + I/A);

    dXdt(2) = an(X(1))*(1-X(2)) - bn(X(1))*X(2);

    dXdt(3) = am(X(1))*(1-X(3)) - bm(X(1))*X(3);

    dXdt(4) = ah(X(1))*(1-X(4)) - bh(X(1))*X(4);
    
    dXdt(5) = 1/tauM(X(1))*(Minf(X(1))-X(5));

    dXdt(6) = 1/tauH(X(1))*(Hinf(X(1))-X(6));
    
    dXdt(7) = -A*(GT*(X(5)^2)*X(6)*(X(1)-vT))/(2*VLM*F)-Kpump*X(7);
    
    dXdt(8) = 1/tauc(X(1))*(cinf(X(1),X(7))-X(8));
    return
end % hhp

%--- Voltage dependent rate functions from  pp 171-172 of [Dayan01] ---

function val = an(v)  % opening rate functions of potassium activation
    val = 0.01*(v+55)/(1-exp(-0.1*(v+55)));
end

function val = bn(v)  % closing rate functions of potassium activation
    val = 0.125*exp(-0.0125*(v+65));
end

function val = am(v)  % opening rate functions of sodium activation
    val = .1*(v+40)/(1-exp(-.1*(v+40)));
end

function val = bm(v)  % closing rate functions of sodium activation
    val = 4*exp(-0.0556*(v+65));
end

function val = ah(v)  % opening rate functions of sodium inactivation
    val = 0.07*exp(-0.05*(v+65));
end

function val = bh(v)  % closing rate functions of sodium inactivation
    val = 1/(1+exp(-0.1*(v+35)));
end

function val = Minf(v)  % opening rate functions of T-type calcium activation
    val = 1/(1+exp(-(v+57)/6.2));
end

function val = tauM(v)  % closing rate functions of T-type calcium activation
    val = 0.612+1/((exp(-(v+132)/16.7)+exp((v+16.8)/18.2)));
end

function val = Hinf(v)  % opening rate functions of T-type calcium inactivation
    val = 1/(1+exp((v+81)/4));
end

function val = tauH(v)  % closing rate functions of T-type calcium inactivation
    if v < -80 
        val = exp((v+467)/66.6);
    else
        val = 28+exp(-(v+22)/10.5);
    end
    
end

function val = cinf(v,c)  % opening rate functions of calcium dependent potassium activation
    val = (c/(c+3))*1/(1+exp(-(v+28.3)/12.6));
end

function val = tauc(v)  % closing rate functions of calcium dependent potassium activation
    val = 90.3-75.1/(1+exp(-(v+46)/22.7));
end
%=== end nested functions ===
end % hh_integrate
