%
% hh_run.m
%
% Interface to solve the HH equations and plot:
%       figure(1)  v, n, m and h
%       figure(2)  v, I_Na, I_K and I_l
%
% PD Roberts, BME-OHSU 01/07 (modified from: Steve Cox, 1/17/03)
%
clear all;

%--- Set model parameters -------------------------------------
tstop = 500;  % Duration of simulation (msec)

% parameters for Hodgkin-Huxley equations (from table 3 of [Hodgkin53])
GNa = 140;           % Maximum sodium current density (mS / cm^2)
%GNa = 200;           % Maximum sodium current density (mS / cm^2)
GK = 36;             % Maximum potassium current density (mS / cm^2)
Gl = 0.3;            % Leak current density (mS / cm^2)
GKca = 100;         % Maximum calcium dependent potassium current density (mS / cm^2)
GT = 50;            % Maximum T-type calcium current density (mS / cm^2)  
vNa = 50;            % Reversal potential for sodium current (mV)
vK = -77;            % Reversal potential for potassium current (mV)
%vl = -54.3;          % Reversal potential for leak current (mV)
vl = -70;          % Reversal potential for leak current (mV)
vT = 120;            % Reversal potential for T-type calcium channel (mV)
Kpump = 1/200;       % Calcium pump rate constant aka 1/TauCa(ms^-1)
F = 96485338;        % Faraday's Constant
HH_param = [GNa GK Gl GKca GT vNa vK vl vT Kpump F];  % Load parameter vector

% stimulus parameters
del = 200;             % Delay until beginning of stimulus (msec)
dur = 10;            % Duration of stimulus (msec)
amp = -0.1;           % Amplitude of stimulus (nA)
stim_param = [del dur amp];  % Load parameter vector

%--- Compute variables -------------------------------------------
[t,x] = hh_integrate_Zach(tstop, HH_param, stim_param);  % Call integrator function  

INa = GNa*(x(:,3).^3).*x(:,4).*(x(:,1)-vNa); % Sodium current for plot
IK = GK*(x(:,2).^4).*(x(:,1)-vK);   % Potassium current for plot
Il = Gl*(x(:,1)-vl);                % Leak current for plot
IT = GT*(x(:,5).^2).*x(:,6).*(x(:,1)-vT);  %Transiant current for plot
IKca = GKca*x(:,8).^4.*(x(:,1)-vK); %calcium dependent potassium current

%--- Plotting functions -------------------------------------------
figure(1)       % Plot membrane potential and activation variables
subplot(3,3,1)
plot(t,x(:,1), 'k')
ylabel('v (mV)','fontsize',16)
xlabel('t (ms)','fontsize',16)
subplot(3,3,2)
plot(t,x(:,8), 'k')
ylabel('c','fontsize',16)
xlabel('t (ms)','fontsize',16)
subplot(3,3,3)
plot(t,x(:,2), 'r')
ylabel('n','fontsize',16)
xlabel('t (ms)','fontsize',16)
subplot(3,3,4)
plot(t,x(:,3), 'b')
xlabel('t (ms)','fontsize',16)
ylabel('m','fontsize',16)
subplot(3,3,5)
plot(t,x(:,4), 'g')
xlabel('t (ms)','fontsize',16)
ylabel('h','fontsize',16)
subplot(3,3,6)
plot(t,x(:,5), 'k')
ylabel('M','fontsize',16)
xlabel('t (ms)','fontsize',16)
subplot(3,3,7)
plot(t,x(:,6), 'k')
ylabel('H','fontsize',16)
xlabel('t (ms)','fontsize',16)
subplot(3,3,8)
plot(t,x(:,7), 'k')
ylabel('[Ca++] (uM)', 'fontsize',16)
xlabel('t (ms)','fontsize',16)

figure(2)       % Plot membrane potential and currents
subplot(3,2,1)
plot(t,x(:,1), 'k')
xlabel('t (ms)','fontsize',16)
ylabel('v (mV)','fontsize',16)
subplot(3,2,2)
plot(t,INa, 'r')
xlabel('t (ms)','fontsize',16)
ylabel('I_{Na}','fontsize',16)
subplot(3,2,3)
plot(t,IK, 'b')
xlabel('t (ms)','fontsize',16)
ylabel('I_K','fontsize',16)
subplot(3,2,4)
plot(t,Il, 'k')
xlabel('t (ms)','fontsize',16)
ylabel('I_l','fontsize',16)
subplot(3,2,5)
plot(t,IT, 'k')
xlabel('t (ms)','fontsize',16)
ylabel('I_T','fontsize',16)
subplot(3,2,6)
plot(t,IKca, 'k')
xlabel('t (ms)','fontsize',16)
ylabel('I_Kca','fontsize',16)

